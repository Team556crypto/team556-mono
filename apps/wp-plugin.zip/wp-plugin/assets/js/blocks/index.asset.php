<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-element', 'wp-html-entities', 'wp-i18n'), 'version' => '455c12907ecc0d884313');
