<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-element', 'wp-html-entities', 'wp-i18n'), 'version' => '2daa82fff668103d20ab');
