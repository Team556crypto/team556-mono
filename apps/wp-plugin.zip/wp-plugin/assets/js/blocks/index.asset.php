<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-element', 'wp-html-entities', 'wp-i18n'), 'version' => '8edc194e13f09290c48d');
