<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-element', 'wp-html-entities', 'wp-i18n'), 'version' => '8fadc4f3ec5b0e6014f5');
