<?php
/**
 * Team556 Solana Pay Dashboard
 * Handles the admin dashboard for the plugin
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Dashboard Class
 */
class Team556_Solana_Pay_Dashboard {
    /**
     * Constructor
     */
    public function __construct() {
        // Add admin menu item
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Add dashboard widgets
        add_action('wp_dashboard_setup', array($this, 'add_dashboard_widgets'));
        
        // Add admin scripts and styles
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // Add body class for our pages
        add_filter('admin_body_class', array($this, 'add_admin_body_class'));
    }

    /**
     * Add admin menu item
     */
    public function add_admin_menu() {
        // Main dashboard page
        add_menu_page(
            __('Team556 Solana Pay', 'team556-solana-pay'),
            __('Team556 Pay', 'team556-solana-pay'),
            'manage_options',
            'team556-solana-pay',
            array($this, 'render_dashboard_page'),
            'dashicons-money-alt',
            30
        );
        
        // Dashboard submenu
        add_submenu_page(
            'team556-solana-pay',
            __('Dashboard', 'team556-solana-pay'),
            __('Dashboard', 'team556-solana-pay'),
            'manage_options',
            'team556-solana-pay',
            array($this, 'render_dashboard_page')
        );
        
        // Transactions submenu
        add_submenu_page(
            'team556-solana-pay',
            __('Transactions', 'team556-solana-pay'),
            __('Transactions', 'team556-solana-pay'),
            'manage_options',
            'team556-solana-pay-transactions',
            array($this, 'render_transactions_page')
        );
        
        // Settings submenu - link to the settings page in the options menu
        add_submenu_page(
            'team556-solana-pay',
            __('Settings', 'team556-solana-pay'),
            __('Settings', 'team556-solana-pay'),
            'manage_options',
            'team556-solana-settings',
            array($this, 'render_settings_redirect')
        );
        
        // Help submenu
        add_submenu_page(
            'team556-solana-pay',
            __('Help', 'team556-solana-pay'),
            __('Help', 'team556-solana-pay'),
            'manage_options',
            'team556-solana-pay-help',
            array($this, 'render_help_page')
        );
    }

    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        // Only enqueue on our plugin pages
        if (strpos($hook, 'team556-solana') === false) {
            return;
        }
        
        // Enqueue admin styles
        wp_enqueue_style(
            'team556-solana-pay-admin',
            TEAM556_SOLANA_PAY_PLUGIN_URL . 'assets/css/team556-solana-pay-admin.css',
            array(),
            TEAM556_SOLANA_PAY_VERSION
        );
        
        // Enqueue admin scripts
        wp_enqueue_script(
            'team556-solana-pay-admin',
            TEAM556_SOLANA_PAY_PLUGIN_URL . 'assets/js/team556-solana-pay-admin.js',
            array('jquery'),
            TEAM556_SOLANA_PAY_VERSION,
            true
        );
        
        // Localize script
        wp_localize_script('team556-solana-pay-admin', 'team556SolanaPayAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('team556-solana-pay-admin-nonce'),
            'i18n'    => array(
                'confirmDelete' => __('Are you sure you want to delete this transaction?', 'team556-solana-pay'),
                'deletingTransaction' => __('Deleting transaction...', 'team556-solana-pay'),
                'transactionDeleted' => __('Transaction deleted successfully.', 'team556-solana-pay'),
                'error' => __('An error occurred.', 'team556-solana-pay'),
            ),
        ));
    }
    
    /**
     * Add admin body class for dark theme
     */
    public function add_admin_body_class($classes) {
        global $current_screen;
        
        // Add our class only to our plugin screens
        if (strpos($current_screen->base, 'team556-solana') !== false) {
            $classes .= ' team556-dark-theme ';
        }
        
        return $classes;
    }

    /**
     * Add dashboard widgets
     */
    public function add_dashboard_widgets() {
        // Only add for users who can manage options
        if (!current_user_can('manage_options')) {
            return;
        }
        
        wp_add_dashboard_widget(
            'team556_solana_pay_stats_widget',
            __('Team556 Solana Pay Stats', 'team556-solana-pay'),
            array($this, 'render_dashboard_widget')
        );
    }

    /**
     * Render dashboard widget
     */
    public function render_dashboard_widget() {
        // Get transactions data
        $db = new Team556_Solana_Pay_DB();
        
        $total_transactions = $db->count_transactions();
        $successful_transactions = $db->count_transactions(array('status' => 'completed'));
        $pending_transactions = $db->count_transactions(array('status' => 'pending'));
        $failed_transactions = $db->count_transactions(array('status' => 'failed'));
        
        // Calculate success rate
        $success_rate = ($total_transactions > 0) ? ($successful_transactions / $total_transactions) * 100 : 0;
        
        // Get recent transactions
        $recent_transactions = $db->get_transactions(array(
            'number' => 5,
            'order' => 'DESC',
            'orderby' => 'created_at'
        ));
        
        // Display stats
        ?>
        <div class="team556-dark-theme-wrapper">
            <div class="team556-stats-grid">
                <div class="team556-stat-card">
                    <div class="team556-stat-value"><?php echo esc_html($total_transactions); ?></div>
                    <div class="team556-stat-label"><?php _e('Total Transactions', 'team556-solana-pay'); ?></div>
                </div>
                
                <div class="team556-stat-card">
                    <div class="team556-stat-value"><?php echo esc_html($successful_transactions); ?></div>
                    <div class="team556-stat-label"><?php _e('Successful', 'team556-solana-pay'); ?></div>
                </div>
                
                <div class="team556-stat-card">
                    <div class="team556-stat-value"><?php echo esc_html($pending_transactions); ?></div>
                    <div class="team556-stat-label"><?php _e('Pending', 'team556-solana-pay'); ?></div>
                </div>
                
                <div class="team556-stat-card">
                    <div class="team556-stat-value"><?php echo round($success_rate, 1); ?>%</div>
                    <div class="team556-stat-label"><?php _e('Success Rate', 'team556-solana-pay'); ?></div>
                </div>
            </div>
            
            <?php if (!empty($recent_transactions)) : ?>
                <h3><?php _e('Recent Transactions', 'team556-solana-pay'); ?></h3>
                <div class="team556-transaction-list">
                    <?php foreach ($recent_transactions as $transaction) : 
                        $explorer_url = sprintf(
                            'https://explorer.solana.com/tx/%s?cluster=%s',
                            $transaction->signature,
                            get_option('team556_solana_pay_network', 'mainnet') === 'mainnet' ? 'mainnet-beta' : 'devnet'
                        );
                    ?>
                        <div class="team556-transaction-card">
                            <div class="team556-tx-main-info">
                                <div class="team556-tx-signature">
                                    <a href="<?php echo esc_url($explorer_url); ?>" target="_blank" title="<?php echo esc_attr($transaction->signature); ?>">
                                        <?php echo esc_html(substr($transaction->signature, 0, 8) . '...' . substr($transaction->signature, -8)); ?>
                                        <span class="dashicons dashicons-external"></span>
                                    </a>
                                </div>
                                <div class="team556-tx-date">
                                    <?php echo esc_html(human_time_diff(strtotime($transaction->created_at), current_time('timestamp'))) . ' ' . __('ago', 'team556-solana-pay'); ?>
                                </div>
                            </div>
                            <div class="team556-tx-details">
                                <div class="team556-tx-amount">
                                    <?php /* TODO: Add token symbol/formatting */ ?>
                                    <?php echo esc_html($transaction->amount); ?>
                                </div>
                                <div class="team556-tx-status">
                                    <span class="team556-status team556-status-<?php echo esc_attr($transaction->status); ?>">
                                        <?php echo esc_html(ucfirst($transaction->status)); ?>
                                    </span>
                                </div>
                            </div>
                            <div class="team556-tx-extra-info">
                                 <?php if (!empty($transaction->order_id)) : ?>
                                    <div class="team556-tx-order">
                                        <?php _e('Order:', 'team556-solana-pay'); ?> 
                                        <a href="<?php echo esc_url(admin_url('post.php?post=' . $transaction->order_id . '&action=edit')); ?>" target="_blank">
                                            #<?php echo esc_html($transaction->order_id); ?>
                                        </a>
                                    </div>
                                 <?php endif; ?>
                                 <div class="team556-tx-payer" title="<?php echo esc_attr($transaction->wallet_address); ?>">
                                    <?php _e('Payer:', 'team556-solana-pay'); ?>
                                    <?php echo esc_html(substr($transaction->wallet_address, 0, 4) . '...' . substr($transaction->wallet_address, -4)); ?>
                                 </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <p class="team556-view-all">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=team556-solana-transactions')); ?>" class="team556-button">
                        <?php _e('View All Transactions', 'team556-solana-pay'); ?>
                    </a>
                </p>
            <?php else : ?>
                <div class="team556-empty-state">
                    <p><?php _e('No transactions yet.', 'team556-solana-pay'); ?></p>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render dashboard page
     */
    public function render_dashboard_page() {
        // Get DB instance
        $db = new Team556_Solana_Pay_DB();
        
        // Get stats
        $total_transactions = $db->count_transactions();
        $successful_transactions = $db->count_transactions(array('status' => 'completed'));
        $pending_transactions = $db->count_transactions(array('status' => 'pending'));
        $failed_transactions = $db->count_transactions(array('status' => 'failed'));
        
        // Calculate success rate
        // $success_rate = ($total_transactions > 0) ? ($successful_transactions / $total_transactions) * 100 : 0; // Not used for now
        
        // Get payment wallet and token settings
        $wallet_address = get_option('team556_solana_pay_wallet_address', '');
        
        // Recent transactions
        $recent_transactions = $db->get_transactions(array(
            'number' => 10,
            'order' => 'DESC',
            'orderby' => 'created_at'
        ));
        
        // Calculate total amount received
        $total_amount_raw = 0;
        foreach ($db->get_transactions(array('status' => 'completed')) as $transaction) {
            $total_amount_raw += floatval($transaction->amount);
        }
        // TODO: Add token formatting based on decimals if needed
        $total_amount_display = number_format($total_amount_raw, 2); // Basic formatting
        
        ?>
        <div class="wrap team556-admin-dashboard team556-dark-theme-wrapper">
            <h1><?php _e('Team556 Solana Pay Dashboard', 'team556-solana-pay'); ?></h1>
            
            <div class="team556-dashboard-header team556-portfolio-card">
                <div class="team556-portfolio-info">
                    <?php if (!empty($wallet_address)) : ?>
                        <div class="team556-portfolio-wallet">
                            <span class="dashicons dashicons-admin-users team556-portfolio-icon"></span>
                            <div class="team556-portfolio-details">
                                <h2><?php _e('Merchant Wallet', 'team556-solana-pay'); ?></h2>
                                <div class="team556-wallet-address">
                                    <?php echo esc_html(substr($wallet_address, 0, 6) . '...' . substr($wallet_address, -6)); ?>
                                    <span class="team556-clipboard-copy" data-clipboard="<?php echo esc_attr($wallet_address); ?>">
                                        <span class="dashicons dashicons-clipboard"></span>
                                    </span>
                                </div>
                                <div class="team556-wallet-network">
                                    <?php echo esc_html(ucfirst(get_option('team556_solana_pay_network', 'mainnet'))); ?>
                                </div>
                            </div>
                        </div>
                        <div class="team556-portfolio-balance">
                            <div class="team556-balance-value"><?php echo esc_html($total_amount_display); ?></div>
                            <div class="team556-balance-label"><?php _e('Total Received (Completed)', 'team556-solana-pay'); ?></div>
                            <?php /* TODO: Potentially add token symbol here */ ?>
                        </div>
                    <?php else : ?>
                        <div class="team556-wallet-not-configured">
                            <p><?php _e('Your wallet is not configured yet.', 'team556-solana-pay'); ?></p>
                            <a href="<?php echo esc_url(admin_url('options-general.php?page=team556-solana-settings')); ?>" class="team556-button">
                                <?php _e('Configure Now', 'team556-solana-pay'); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="team556-action-buttons">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=team556-solana-pay-transactions')); ?>" class="team556-button secondary">
                        <span class="dashicons dashicons-list-view"></span>
                        <?php _e('View All Transactions', 'team556-solana-pay'); ?>
                    </a>
                    <a href="<?php echo esc_url(admin_url('options-general.php?page=team556-solana-settings')); ?>" class="team556-button outline">
                        <span class="dashicons dashicons-admin-settings"></span>
                        <?php _e('Settings', 'team556-solana-pay'); ?>
                    </a>
                </div>
            </div>
            
            <div class="team556-dashboard-recent">
                <h2><?php _e('Recent Transactions', 'team556-solana-pay'); ?></h2>
                
                <?php if (!empty($recent_transactions)) : ?>
                    <div class="team556-transaction-list"> 
                        <?php foreach ($recent_transactions as $transaction) : 
                            $explorer_url = sprintf(
                                'https://explorer.solana.com/tx/%s?cluster=%s',
                                $transaction->signature,
                                get_option('team556_solana_pay_network', 'mainnet') === 'mainnet' ? 'mainnet-beta' : 'devnet'
                            );
                        ?>
                            <div class="team556-transaction-card">
                                <div class="team556-tx-main-info">
                                    <div class="team556-tx-signature">
                                        <a href="<?php echo esc_url($explorer_url); ?>" target="_blank" title="<?php echo esc_attr($transaction->signature); ?>">
                                            <?php echo esc_html(substr($transaction->signature, 0, 8) . '...' . substr($transaction->signature, -8)); ?>
                                            <span class="dashicons dashicons-external"></span>
                                        </a>
                                    </div>
                                    <div class="team556-tx-date">
                                        <?php echo esc_html(human_time_diff(strtotime($transaction->created_at), current_time('timestamp'))) . ' ' . __('ago', 'team556-solana-pay'); ?>
                                    </div>
                                </div>
                                <div class="team556-tx-details">
                                    <div class="team556-tx-amount">
                                        <?php /* TODO: Add token symbol/formatting */ ?>
                                        <?php echo esc_html($transaction->amount); ?>
                                    </div>
                                    <div class="team556-tx-status">
                                        <span class="team556-status team556-status-<?php echo esc_attr($transaction->status); ?>">
                                            <?php echo esc_html(ucfirst($transaction->status)); ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="team556-tx-extra-info">
                                     <?php if (!empty($transaction->order_id)) : ?>
                                        <div class="team556-tx-order">
                                            <?php _e('Order:', 'team556-solana-pay'); ?> 
                                            <a href="<?php echo esc_url(admin_url('post.php?post=' . $transaction->order_id . '&action=edit')); ?>" target="_blank">
                                                #<?php echo esc_html($transaction->order_id); ?>
                                            </a>
                                        </div>
                                     <?php endif; ?>
                                     <div class="team556-tx-payer" title="<?php echo esc_attr($transaction->wallet_address); ?>">
                                        <?php _e('Payer:', 'team556-solana-pay'); ?>
                                        <?php echo esc_html(substr($transaction->wallet_address, 0, 4) . '...' . substr($transaction->wallet_address, -4)); ?>
                                     </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div> 
                    
                    <?php /* REMOVED View All Button - Now in header */ ?>
                    
                <?php else : ?>
                    <div class="team556-empty-state">
                        <p><?php _e('No transactions have been recorded yet.', 'team556-solana-pay'); ?></p>
                        <p><?php _e('Once customers start making payments with Team556 tokens, you\'ll see them here.', 'team556-solana-pay'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="team556-dashboard-help">
                <h2><?php _e('Getting Started', 'team556-solana-pay'); ?></h2>
                <div class="team556-help-wrapper">
                    <div class="team556-help-step">
                        <div class="team556-step-number">1</div>
                        <div class="team556-step-content">
                            <h3><?php _e('Configure Settings', 'team556-solana-pay'); ?></h3>
                            <p><?php _e('Enter your Solana wallet address and Team556 token details in the plugin settings.', 'team556-solana-pay'); ?></p>
                            <a href="<?php echo esc_url(admin_url('options-general.php?page=team556-solana-settings')); ?>" class="team556-button">
                                <?php _e('Go to Settings', 'team556-solana-pay'); ?>
                            </a>
                        </div>
                    </div>
                    
                    <div class="team556-help-step">
                        <div class="team556-step-number">2</div>
                        <div class="team556-step-content">
                            <h3><?php _e('Add Payment Buttons', 'team556-solana-pay'); ?></h3>
                            <p><?php _e('Use the shortcode to add payment buttons to any page or post.', 'team556-solana-pay'); ?></p>
                            <code>[team556_solana_pay amount="10" description="My Product" button_text="Pay Now"]</code>
                        </div>
                    </div>
                    
                    <div class="team556-help-step">
                        <div class="team556-step-number">3</div>
                        <div class="team556-step-content">
                            <h3><?php _e('Enable in WooCommerce', 'team556-solana-pay'); ?></h3>
                            <p><?php _e('If you use WooCommerce, Team556 Solana Pay has been automatically enabled. You can adjust settings in your payment methods.', 'team556-solana-pay'); ?></p>
                            <?php if (class_exists('WooCommerce')) : ?>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=wc-settings&tab=checkout')); ?>" class="team556-button">
                                    <?php _e('WooCommerce Payment Settings', 'team556-solana-pay'); ?>
                                </a>
                            <?php else : ?>
                                <p><em><?php _e('WooCommerce is not installed or activated.', 'team556-solana-pay'); ?></em></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render transactions page
     */
    public function render_transactions_page() {
        // Get DB instance
        $db = new Team556_Solana_Pay_DB();
        
        // Process actions
        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id']) && current_user_can('manage_options')) {
            $transaction_id = intval($_GET['id']);
            $nonce = isset($_GET['_wpnonce']) ? $_GET['_wpnonce'] : '';
            
            if (wp_verify_nonce($nonce, 'delete_transaction_' . $transaction_id)) {
                $db->delete_transaction($transaction_id);
                
                // Redirect to remove the action from URL
                wp_redirect(admin_url('admin.php?page=team556-solana-transactions&deleted=1'));
                exit;
            }
        }
        
        // Get filter values
        $status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
        $order_id_filter = isset($_GET['order_id']) ? intval($_GET['order_id']) : null;
        
        // Pagination
        $per_page = 20;
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $offset = ($current_page - 1) * $per_page;
        
        // Get transactions
        $args = array(
            'number' => $per_page,
            'offset' => $offset,
            'order' => 'DESC',
            'orderby' => 'created_at'
        );
        
        if (!empty($status_filter)) {
            $args['status'] = $status_filter;
        }
        
        if (!empty($order_id_filter)) {
            $args['order_id'] = $order_id_filter;
        }
        
        $transactions = $db->get_transactions($args);
        $total_transactions = $db->count_transactions($args);
        
        $total_pages = ceil($total_transactions / $per_page);
        
        ?>
        <div class="wrap team556-admin-transactions team556-dark-theme-wrapper">
            <h1 class="wp-heading-inline"><?php _e('Team556 Solana Pay Transactions', 'team556-solana-pay'); ?></h1>
            
            <?php if (isset($_GET['deleted']) && $_GET['deleted'] == 1) : ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php _e('Transaction deleted successfully.', 'team556-solana-pay'); ?></p>
                </div>
            <?php endif; ?>
            
            <div class="team556-transactions-filters">
                <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>">
                    <input type="hidden" name="page" value="team556-solana-transactions">
                    
                    <select name="status">
                        <option value=""><?php _e('All Statuses', 'team556-solana-pay'); ?></option>
                        <option value="pending" <?php selected($status_filter, 'pending'); ?>><?php _e('Pending', 'team556-solana-pay'); ?></option>
                        <option value="completed" <?php selected($status_filter, 'completed'); ?>><?php _e('Completed', 'team556-solana-pay'); ?></option>
                        <option value="failed" <?php selected($status_filter, 'failed'); ?>><?php _e('Failed', 'team556-solana-pay'); ?></option>
                    </select>
                    
                    <input type="number" name="order_id" placeholder="<?php esc_attr_e('Order ID', 'team556-solana-pay'); ?>" value="<?php echo esc_attr($order_id_filter !== null ? $order_id_filter : ''); ?>">
                    
                    <button type="submit" class="team556-button"><?php _e('Filter', 'team556-solana-pay'); ?></button>
                    
                    <?php if (!empty($status_filter) || !empty($order_id_filter)) : ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=team556-solana-transactions')); ?>" class="team556-button outline"><?php _e('Reset', 'team556-solana-pay'); ?></a>
                    <?php endif; ?>
                </form>
            </div>
            
            <?php if (!empty($transactions)) : ?>
                <table class="wp-list-table widefat fixed striped team556-transactions-table">
                    <thead>
                        <tr>
                            <th><?php _e('ID', 'team556-solana-pay'); ?></th>
                            <th><?php _e('Transaction Signature', 'team556-solana-pay'); ?></th>
                            <th><?php _e('Wallet Address', 'team556-solana-pay'); ?></th>
                            <th><?php _e('Amount', 'team556-solana-pay'); ?></th>
                            <th><?php _e('Order ID', 'team556-solana-pay'); ?></th>
                            <th><?php _e('Status', 'team556-solana-pay'); ?></th>
                            <th><?php _e('Date', 'team556-solana-pay'); ?></th>
                            <th><?php _e('Actions', 'team556-solana-pay'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($transactions as $transaction) : ?>
                            <tr>
                                <td><?php echo esc_html($transaction->id); ?></td>
                                <td>
                                    <span class="team556-signature-short">
                                        <?php echo esc_html(substr($transaction->transaction_signature, 0, 8) . '...' . substr($transaction->transaction_signature, -8)); ?>
                                    </span>
                                    <span class="team556-clipboard-copy" data-clipboard="<?php echo esc_attr($transaction->transaction_signature); ?>">
                                        <span class="dashicons dashicons-clipboard"></span>
                                    </span>
                                    <div class="row-actions">
                                        <span class="view">
                                            <?php 
                                            $network = get_option('team556_solana_pay_network', 'mainnet');
                                            $explorer_url = 'https://explorer.solana.com/tx/' . $transaction->transaction_signature;
                                            
                                            if ($network === 'devnet') {
                                                $explorer_url .= '?cluster=devnet';
                                            } elseif ($network === 'testnet') {
                                                $explorer_url .= '?cluster=testnet';
                                            }
                                            ?>
                                            <a href="<?php echo esc_url($explorer_url); ?>" target="_blank">
                                                <?php _e('View on Explorer', 'team556-solana-pay'); ?>
                                            </a>
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <span class="team556-wallet-short">
                                        <?php echo esc_html(substr($transaction->wallet_address, 0, 8) . '...' . substr($transaction->wallet_address, -8)); ?>
                                    </span>
                                    <span class="team556-clipboard-copy" data-clipboard="<?php echo esc_attr($transaction->wallet_address); ?>">
                                        <span class="dashicons dashicons-clipboard"></span>
                                    </span>
                                </td>
                                <td><?php echo esc_html($transaction->amount); ?></td>
                                <td>
                                    <?php if (!empty($transaction->order_id)) : ?>
                                        <a href="<?php echo esc_url(admin_url('post.php?post=' . $transaction->order_id . '&action=edit')); ?>" target="_blank">
                                            <?php echo esc_html($transaction->order_id); ?>
                                        </a>
                                    <?php else : ?>
                                        &mdash;
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="team556-status team556-status-<?php echo esc_attr($transaction->status); ?>">
                                        <?php echo esc_html(ucfirst($transaction->status)); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($transaction->created_at))); ?></td>
                                <td>
                                    <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=team556-solana-transactions&action=delete&id=' . $transaction->id), 'delete_transaction_' . $transaction->id)); ?>" class="team556-delete-transaction" onclick="return confirm('<?php esc_attr_e('Are you sure you want to delete this transaction?', 'team556-solana-pay'); ?>');">
                                        <span class="dashicons dashicons-trash"></span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <?php if ($total_pages > 1) : ?>
                    <div class="tablenav">
                        <div class="tablenav-pages">
                            <?php
                            echo paginate_links(array(
                                'base' => add_query_arg('paged', '%#%'),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $total_pages,
                                'current' => $current_page
                            ));
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
                
            <?php else : ?>
                <div class="team556-empty-state">
                    <p><?php _e('No transactions found.', 'team556-solana-pay'); ?></p>
                    <?php if (!empty($status_filter) || !empty($order_id_filter)) : ?>
                        <p>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=team556-solana-transactions')); ?>" class="team556-button">
                                <?php _e('Clear Filters', 'team556-solana-pay'); ?>
                            </a>
                        </p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Settings redirect - redirects to the options page
     */
    public function render_settings_redirect() {
        ?>
        <script type="text/javascript">
            window.location.href = "<?php echo esc_url(admin_url('options-general.php?page=team556-solana-settings')); ?>";
        </script>
        <?php
        _e('Redirecting to settings page...', 'team556-solana-pay');
    }
} 